﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lab2q1
{
    class sqube
    {  
        struct squareorcube
        {
            public int Number;
            public int Squar()
            {
                
                return Number * Number;
            }
            public int Cub()
            {
                
                return Number * Number * Number;
            }

        }
        static void Main(string[] args)
        {
            string a;
            squareorcube num;
            num.Number = 4;
            Console.WriteLine("Enter your choice (sq or cu)");
            a = Console.ReadLine();
            if(a == "sq")
            {
                Console.WriteLine("Square of the Entered Number: " + num.Squar());
            }
            else if (a == "cu")
            {
                Console.WriteLine("Cube of the Entered Number: " + num.Cub());
            }
            else { Console.WriteLine("Invalid choice"); }
            Console.ReadKey();
        }
    }
}
